from django.apps import AppConfig


class SaccessResponseConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'success_response'
